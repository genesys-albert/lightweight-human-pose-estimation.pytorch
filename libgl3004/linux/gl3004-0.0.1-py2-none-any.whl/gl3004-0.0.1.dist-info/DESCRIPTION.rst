# GL3004 Python Module

This module is a wrapper to shared-library from libgl3004.

## Build Python Wheel

install package **wheel**

```
pip install wheel
```

then, run:

```
python setup.py bdist_wheel
```

## Install for global

```
python setup.py install
```

## Install for current user

```
python setup.py install --user
```

## Uninstall

```
pip uninstall gl3004
```


