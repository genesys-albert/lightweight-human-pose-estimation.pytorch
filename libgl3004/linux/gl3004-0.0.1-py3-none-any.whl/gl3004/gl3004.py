from __future__ import print_function
import pkg_resources
import sys, ctypes

if sys.platform.startswith('linux'):
  lib_path = pkg_resources.resource_filename('gl3004', 'libgl3004-shared.so')
elif sys.platform.startswith('win32'):
  lib_path = pkg_resources.resource_filename('gl3004', 'gl3004-shared.dll')
elif sys.platform.startswith('darwin'):
  lib_path = pkg_resources.resource_filename('gl3004', 'libgl3004-shared.dylib')
else:
  raise Exception('Unknown Platform')

lib = ctypes.cdll.LoadLibrary(lib_path)

class DeviceInfo(ctypes.Structure):
  _fields_ = [('name', ctypes.c_char * 64),
              ('path', ctypes.c_char * 256)]

class Device:
  def __init__(self, dev_info):
    if not isinstance(dev_info, DeviceInfo):
      raise Exception('device_info type error')
    dev_ctx = ctypes.c_void_p()
    dev_ctx_ptr = ctypes.pointer(dev_ctx)
    dev_info_ptr = ctypes.pointer(dev_info)
    if lib.gl3004_uvc_open(dev_info_ptr, dev_ctx_ptr) != 0:
      raise Exception('failed to open device(name: {}, path: {})'.format(dev_info.name, dev_info.path))
    self._dev_ctx = dev_ctx
  
  def __del__(self):
    lib.gl3004_uvc_close(self._dev_ctx)
  
  def xdata_read(self, address, num_bytes):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(num_bytes, int):
      raise Exception('num_bytes must be an integer.')
    address = ctypes.c_uint16(address)
    data = ctypes.create_string_buffer(num_bytes)
    num_bytes = ctypes.c_uint(num_bytes)
    if lib.gl3004_xdata_read(self._dev_ctx, address, data, num_bytes) < 0:
      raise Exception('failed to read xdata.')
    return bytearray(data.raw)

  def xdata_write(self, address, data):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(data, bytearray):
      raise Exception('data must be a byrearray.')
    address = ctypes.c_uint16(address)
    buf = (ctypes.c_ubyte * len(data))(*data)
    num_bytes = ctypes.c_uint(len(data))
    if lib.gl3004_xdata_write(self._dev_ctx, address, buf, num_bytes) < 0:
      raise Exception('failed to write xdata.')

  def axi_read(self, address, num_bytes):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(num_bytes, int):
      raise Exception('num_bytes must be an integer.')
    address = ctypes.c_uint32(address)
    data = ctypes.create_string_buffer(num_bytes)
    num_bytes = ctypes.c_uint(num_bytes)
    if lib.gl3004_axi_read(self._dev_ctx, address, data, num_bytes) < 0:
      raise Exception('failed to read axi.')
    return bytearray(data.raw)

  def axi_write(self, address, data):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(data, bytearray):
      raise Exception('data must be a byrearray.')
    address = ctypes.c_uint32(address)
    buf = (ctypes.c_ubyte * len(data))(*data)
    num_bytes = ctypes.c_uint(len(data))
    if lib.gl3004_axi_write(self._dev_ctx, address, buf, num_bytes) < 0:
      raise Exception('failed to write axi.')

  def flash_erase(self, index, unit):
    supported_units = {'sector': 0, 'block': 1, 'whole': 2}
    if not isinstance(index, int):
      raise Exception('index must be an integer.')
    if unit not in supported_units:
      raise Exception('unit "{}" is not supported.'.format(unit))
    index = ctypes.c_uint16(index)
    unit = ctypes.c_uint8(supported_units[unit])
    if lib.gl3004_flash_erase(self._dev_ctx, index, unit) != 0:
      raise Exception('failed to erase flash.')

  def flash_read(self, address, num_bytes):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(num_bytes, int):
      raise Exception('num_bytes must be an integer.')
    address = ctypes.c_uint32(address)
    data = ctypes.create_string_buffer(num_bytes)
    num_bytes = ctypes.c_uint(num_bytes)
    if lib.gl3004_flash_read(self._dev_ctx, address, data, num_bytes) < 0:
      raise Exception('failed to read flash.')
    return bytearray(data.raw)

  def flash_write(self, address, data):
    if not isinstance(address, int):
      raise Exception('address must be an integer.')
    if not isinstance(data, bytearray):
      raise Exception('data must be a byrearray.')
    address = ctypes.c_uint32(address)
    buf = (ctypes.c_ubyte * len(data))(*data)
    num_bytes = ctypes.c_uint(len(data))
    if lib.gl3004_flash_write(self._dev_ctx, address, buf, num_bytes) < 0:
      raise Exception('failed to write flash.')

  def version(self):
    buf = ctypes.create_string_buffer(128)
    buf_len = ctypes.c_uint(len(buf))
    if lib.gl3004_firmware_version(self._dev_ctx, buf, buf_len) < 0:
      raise Exception('failed to read firmware version.')
    return str(buf.raw)

  def mode_change(self, mode):
    if not isinstance(mode, int):
      raise Exception('mode must be an integer.')
    mode = ctypes.c_uint8(mode)
    if lib.gl3004_mode_change(self._dev_ctx, mode) < 0:
      raise Exception('failed to change mode of view.')

  def pan(self, window, angle):
    if not isinstance(window, int):
      raise Exception('window must be an integer.')
    if not isinstance(angle, float) and not isinstance(angle, int):
      raise Exception('angle must be an floating integer.')
    window = ctypes.c_uint8(window)
    angle = ctypes.c_float(float(angle))
    if lib.gl3004_pan(self._dev_ctx, window, angle) < 0:
      raise Exception('failed to pan current view.')

  def tilt(self, window, angle):
    if not isinstance(window, int):
      raise Exception('window must be an integer.')
    if not isinstance(angle, float) and not isinstance(angle, int):
      raise Exception('angle must be an floating integer.')
    window = ctypes.c_uint8(window)
    angle = ctypes.c_float(float(angle))
    if lib.gl3004_tilt(self._dev_ctx, window, angle) < 0:
      raise Exception('failed to tilt current view.')

  def zoom(self, window, ratio):
    if not isinstance(window, int):
      raise Exception('window must be an integer.')
    if not isinstance(ratio, float) and not isinstance(ratio, int):
      raise Exception('ratio must be an floating integer.')
    window = ctypes.c_uint8(window)
    ratio = ctypes.c_float(float(ratio))
    if lib.gl3004_zoom(self._dev_ctx, window, ratio) < 0:
      raise Exception('failed to zoom current view.')

  def focus(self, window, x, y, ratio):
    if not isinstance(window, int):
      raise Exception('window must be an integer.')
    if not isinstance(x, int):
      raise Exception('x must be an integer.')
    if not isinstance(y, int):
      raise Exception('y must be an integer.')
    if not isinstance(ratio, float) and not isinstance(ratio, int):
      raise Exception('ratio must be an floating integer.')
    window = ctypes.c_uint8(window)
    x = ctypes.c_uint16(x)
    y = ctypes.c_uint16(y)
    ratio = ctypes.c_float(float(ratio))
    if lib.gl3004_focus(self._dev_ctx, window, x, y, ratio) < 0:
      raise Exception('failed to focus current view.')

  def shift(self, window, x, y):
    if not isinstance(window, int):
      raise Exception('window must be an integer.')
    if not isinstance(x, int):
      raise Exception('x must be an integer.')
    if not isinstance(y, int):
      raise Exception('y must be an integer.')
    window = ctypes.c_uint8(window)
    x = ctypes.c_uint16(x)
    y = ctypes.c_uint16(y)
    if lib.gl3004_shift(self._dev_ctx, window, x, y) < 0:
      raise Exception('failed to shift current view.')

  def reboot(self, boot_mode=True):
    if not isinstance(boot_mode, bool):
      raise Exception('boot_mode must be boolean value.')
    boot_mode = ctypes.c_uint8(1) if boot_mode else ctypes.c_uint8(0)
    if lib.gl3004_reboot(self._dev_ctx, boot_mode) < 0:
      raise Exception('failed to reboot.')

def enumerate_device():
  DeviceInfoPointer = ctypes.POINTER(DeviceInfo)
  dev_info = DeviceInfoPointer()
  dev_info_ptr = ctypes.pointer(dev_info)
  num_dev_info = ctypes.c_uint32()
  num_dev_info_ptr = ctypes.pointer(num_dev_info)
  if lib.gl3004_uvc_enumerate(dev_info_ptr, num_dev_info_ptr) != 0:
    return []
  devices = [DeviceInfo(dev_info[i].name, dev_info[i].path) for i in range(num_dev_info.value)]
  lib.gl3004_uvc_device_info_destroy(dev_info)
  return devices
